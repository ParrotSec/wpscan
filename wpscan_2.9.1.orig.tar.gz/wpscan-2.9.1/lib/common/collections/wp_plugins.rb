# encoding: UTF-8

require 'common/collections/wp_plugins/detectable'

class WpPlugins < WpItems
  extend WpPlugins::Detectable

end
